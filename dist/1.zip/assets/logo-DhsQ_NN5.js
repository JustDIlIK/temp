const o="/img/logo/logo.webp";export{o as _};
