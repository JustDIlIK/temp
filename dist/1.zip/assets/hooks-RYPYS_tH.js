const a="https://backend.barakamarket.uz/";export{a as g};
