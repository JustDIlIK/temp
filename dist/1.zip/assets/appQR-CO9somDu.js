const e="/img/logo/logoOrange.png",o="/img/elements/loyalty/img.png",g="/img/elements/vectors/arrow-left.png",s="/img/elements/loyalty/appQR.svg";export{g as A,o as I,e as L,s as Q};
